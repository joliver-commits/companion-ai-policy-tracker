---
name: New instrument
about: A bill or regulation the tracker does not yet cover
title: "[new] "
labels: addition
---

**Jurisdiction and citation:**

**Status and key dates:**

**Operative definition** (quote the text if you have it):

**Narrowing device / carve-out, if any:**

**Mechanisms it carries:**

**Source link:**
