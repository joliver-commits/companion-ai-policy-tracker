---
name: Status update or correction
about: A bill moved, died, took effect, or is coded wrong
title: "[status] "
labels: correction
---

**Instrument** (state/body and bill number):

**Current coding in the tracker:**

**Correct status / coding:**

**Source** (legislature record, statutory text, or analysis):

**Effective date, if newly enacted:**
