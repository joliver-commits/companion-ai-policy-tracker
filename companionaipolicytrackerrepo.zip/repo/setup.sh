#!/usr/bin/env bash
# One-time setup: creates the GitHub repo, pushes, and enables GitHub Pages.
# Requires the GitHub CLI: https://cli.github.com  (brew install gh)
set -e

REPO="companion-ai-policy-tracker"

gh auth status >/dev/null 2>&1 || gh auth login

git init -q
git add -A
git commit -qm "Companion AI Policy Tracker: 53 instruments across US, EU and China"
git branch -M main

gh repo create "$REPO" --public --source=. --push \
  --description "Open dataset of legislation regulating AI companions and conversational AI — US federal & state, EU, China."

OWNER=$(gh api user --jq .login)
gh api -X POST "repos/$OWNER/$REPO/pages" \
  -f "source[branch]=main" -f "source[path]=/" >/dev/null 2>&1 \
  || gh api -X PUT "repos/$OWNER/$REPO/pages" -f "source[branch]=main" -f "source[path]=/" >/dev/null

echo
echo "Done. Your tracker will be live in ~60 seconds at:"
echo "  https://$OWNER.github.io/$REPO/"
echo "Repo: https://github.com/$OWNER/$REPO"
