# Companion AI Policy Tracker

**[→ Open the tracker](https://joliver-commits.github.io/companion-ai-policy-tracker/)**

A structured, open dataset of legislation regulating AI companions and conversational AI systems, covering the **United States** (federal and state), the **European Union**, and **China**.

Maintained at the Berkman Klein Center for Internet & Society, Harvard University.
Last verified: **13 August 2026** · 53 instruments.

---

## Why this exists

Several good bill lists already track chatbot legislation — the [Future of Privacy Forum's 2026 Chatbot Legislation Tracker](https://fpf.org/2026-chatbot-legislation-tracker/) and [MultiState's updates](https://www.multistate.ai/) are the best of them, and this project draws on both.

What this adds is **definitional coding**. For every instrument it records:

| Field | What it captures |
|---|---|
| **Term used** | The label the instrument adopts — "companion chatbot", "AI companion", "chatbot", or no product term at all |
| **Test** | The kind of question the definition asks: capability, behaviour, design purpose, conduct, training objective, or technique-and-effect |
| **Narrowing device** | What pulls systems back *out* of the definition: a marketing carve-out, a use carve-out, a purpose-primacy gate, an age gate, or none |
| **Reaches general assistants** | Whether the text, as written, covers general-purpose systems like ChatGPT, Claude or Gemini |
| **Mechanisms** | Sixteen coded regulatory mechanisms, from non-human disclosure to a duty to test one's own design against harm |

That coding supports a claim the vocabulary obscures: **most of these instruments already define their object functionally — by what a system does rather than what kind of product it is. They diverge on which functions, and their carve-outs quietly reintroduce classification by self-presentation.**

## What the data shows

Across all 53 instruments:

| Mechanism | Instruments |
|---|---|
| Non-human disclosure | 37 |
| Crisis / self-harm protocol | 34 |
| Content limits for minors | 29 |
| Engagement / addictive design limits | 16 |
| Bars simulating dependence or distress | 10 |
| Independent audit | 3 |
| **Memory or retention constraint** | **2** |
| **Human takeover on crisis** | **1** |
| **Duty to test own design against harm** | **1** |

Policies converge where the intervention is cheapest — telling the user the system is not human — and thin out sharply where it would constrain the features that build attachment. No instrument in any jurisdiction sets a session cap, a cooling-off period, or an overnight restriction for minors. No instrument prohibits using a user's retained emotional disclosures to draw them back after they lapse.

## Contents

```
index.html   the tracker interface — five views, no build step, no dependencies
data.js      the dataset: one editable array, 53 records
app.js       rendering, filtering, and the written analysis
```

Everything is plain HTML, CSS and vanilla JavaScript. No framework, no bundler, no network calls. Clone it and open `index.html`, or [use the hosted version](https://joliver-commits.github.io/companion-ai-policy-tracker/).

## Using the data elsewhere

`data.js` defines two globals, `MECHS` and `DATA`. To pull the dataset into Python, Node, R or a spreadsheet, strip the `const` declarations or evaluate the file directly:

```bash
node -e "
  const f = new Function(require('fs').readFileSync('data.js','utf8') + ';return DATA');
  console.log(JSON.stringify(f(), null, 2));
" > instruments.json
```

## Contributing

Corrections and additions are welcome — see [CONTRIBUTING.md](CONTRIBUTING.md).

The highest-value contributions are **enrolled statutory text for instruments currently coded from tracker summaries**. The definitional clause and its carve-out determine the "reaches general assistants" judgement, which is the analytically load-bearing column, and several of the states that enacted law in 2026 are coded from secondary analyses rather than from the enrolled text.

## Scope note

The tracker covers instruments aimed at companion, conversational and anthropomorphic AI systems. It does not attempt to cover general AI governance (the EU AI Act appears only for its Article 5 prohibited-practices provisions), algorithmic discrimination law, or youth online safety law that does not reach conversational systems.

## Licence

Data and written analysis: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
Code: [MIT](LICENSE).

Attribution: *Companion AI Policy Tracker*, Berkman Klein Center for Internet & Society, Harvard University.

## Sources

Primary bill and statutory text via Congress.gov, state legislature records, EUR-Lex and China Law Translate. Status verification and gap-filling via the Future of Privacy Forum, MultiState, Orrick, Troutman Pepper, the Transparency Coalition, EPIC, LegiScan, and individual legislature bill histories. Each record links to the best available reference for that instrument.
